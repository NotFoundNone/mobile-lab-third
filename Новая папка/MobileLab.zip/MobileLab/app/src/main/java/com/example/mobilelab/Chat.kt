package com.example.mobilelab

data class Chat(val name: String, val time: String, val message: String)
